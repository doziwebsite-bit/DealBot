# À propos
Ce site publie automatiquement une sélection de bons plans et actualités tech, avec titres et résumés générés par l'IA. 
Les liens d'affiliation nous aident à couvrir les coûts — merci !