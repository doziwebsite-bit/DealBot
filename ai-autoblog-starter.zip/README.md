# AI Autoblog (revenus passifs par contenu automatisé)

> **Idée** : un petit site statique qui s'auto-alimente chaque nuit via GitHub Actions.
> Il récupère des flux RSS, filtre par mots-clés, génère un **titre + résumé** (IA si vous avez une clé),
> ajoute vos **liens affiliés** si possible, puis publie automatiquement sur GitHub Pages.
> Budget: 0 € d'hébergement. Temps: quelques minutes d'installation.

## ⚙️ Ce que ça fait
- Récupère des articles depuis des `feeds` RSS définis dans `config.yml`
- Filtre par `keywords` (pour rester très niche et capter des clics qualifiés)
- Génère un **titre SEO** + **résumé court** (IA si `OPENAI_API_KEY` est présent, sinon fallback)
- Crée des pages statiques (HTML) avec **Jinja2** + un index
- Appose vos **tags d'affiliation** pour certains domaines (`affiliate_map`)
- Déploie chaque nuit via **GitHub Actions** sur **GitHub Pages**

## 🚀 Démarrage rapide
1. **Créez un repo GitHub** (public) nommé `ai-autoblog` (ou autre).
2. Téléchargez ce dossier et poussez-le sur votre repo.
3. Dans le repo GitHub, activez **Pages** (branche `gh-pages` quand elle existera).
4. (Optionnel) Ajoutez un **secret** `OPENAI_API_KEY` dans *Settings → Secrets and variables → Actions*.
5. Modifiez `config.yml` (site_name, feeds, keywords, affiliate_map).
6. Le workflow va tourner **chaque nuit à 02:30 UTC**. Vous pouvez aussi lancer manuellement (*Run workflow*).

## 🧪 Tester en local
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python scripts/build.py
# Les fichiers générés seront dans dist/
```

Ouvrez `dist/index.html` dans votre navigateur pour voir le rendu.

## 💸 Monétisation
- Renseignez vos tags d'affiliation dans `config.yml` (`affiliate_map`).
- **Niche = roi** : concentrez-vous sur des catégories où vous pouvez vraiment convertir (ex: SSD, smartphones entrée de gamme, consoles d'occas').
- Votre contenu se publiera tous les jours automatiquement ⇒ revenus potentiels même quand vous dormez.

## 🔧 Personnalisation
- Changez le thème dans `templates/base.html` (CSS minimal).
- Ajustez `daily_post_limit` pour rester compact (meilleur SEO initial).
- Ajoutez/retirez des `feeds` en fonction de votre niche.
- Ajoutez des pages (ex: `pages/about.md`) qui seront copiées vers le site.

## 🛡️ Légal & éthique
- Utilise des **RSS publics** (pas de scraping agressif).
- Respectez les CGU des programmes d'affiliation (ex: Amazon n'aime pas certains types d'automations — lisez leurs règles).
- Affichez une mention « liens affiliés » sur le site (inclus en pied de page).

---

*Généré le 2025-08-24*